//PARTE 1 � RECURS�O e MATEM�TICA

void printNaturals(int N);

int sumNaturals(int N);

int nOfDigits(int N);

int DigitSum(int N);

long convertBinary(int decN);

void EvenAndOdd(int valorPadrao, int N);

int reverse(int N);

int findMCD(int a, int b);


