//PARTE 1 � ASCII e STRING


void strUppercase(char *str);

int countVowels(char *str);

void toggleString(char *str);


//PARTE 2 � CHAR e STRING

int findChar(char *str, char caracter);

int countChar(char *str, char caracter);

char findHighestFrequentChar(char *str);

void removeChar(char *str, char caracter);

void replaceChar(char *str, char caracter, char troca);
